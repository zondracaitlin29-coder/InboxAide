import { Inbox, MessageCircle, UserCheck, Filter, Clock, FileText, CheckCircle } from "lucide-react"

const services = [
  {
    icon: Inbox,
    title: "Daily Inbox Sorting",
    description: "We organize and prioritize your messages every day, ensuring nothing important gets lost."
  },
  {
    icon: MessageCircle,
    title: "Professional Comment Replying",
    description: "Thoughtful, on-brand responses to every comment—keeping your audience engaged."
  },
  {
    icon: UserCheck,
    title: "Prompt Inquiry Management",
    description: "Fast, professional responses that convert curious browsers into paying customers."
  },
  {
    icon: Filter,
    title: "Lead Filtering",
    description: "We identify and prioritize hot leads, so you only spend time on ready-to-buy prospects."
  }
]

const pricingFeatures = [
  {
    icon: Clock,
    text: "Monday to Friday, 9am to 5pm"
  },
  {
    icon: CheckCircle,
    text: "3 daily check-ins during business hours"
  },
  {
    icon: FileText,
    text: "Weekly report delivered every Friday"
  }
]

export function SolutionSection() {
  return (
    <section id="services" className="py-20 md:py-28 bg-background">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">
            How We Help Your Business Thrive
          </h2>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-10 mb-16">
          {services.map((service, index) => (
            <div 
              key={index}
              className="flex gap-4"
            >
              {/* Icon */}
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-md bg-accent/10 border border-accent/20 flex items-center justify-center">
                  <service.icon className="w-5 h-5 text-accent" />
                </div>
              </div>
              
              {/* Content */}
              <div>
                <h3 className="font-medium text-foreground mb-1">
                  {service.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Pricing Card */}
        <div className="max-w-xl">
          <div className="bg-card border border-accent/30 rounded-lg p-8 shadow-sm">
            <div className="mb-6">
              <p className="text-sm text-muted-foreground uppercase tracking-wider mb-2">Weekly Rate</p>
              <div className="flex items-baseline gap-1">
                <span className="font-serif text-4xl md:text-5xl font-semibold text-foreground">R450</span>
                <span className="text-muted-foreground">/week</span>
              </div>
            </div>

            <div className="space-y-4">
              {pricingFeatures.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <feature.icon className="w-5 h-5 text-accent flex-shrink-0" />
                  <span className="text-sm text-foreground">{feature.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
