import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="pt-28 pb-20 md:pt-32 md:pb-28">
      <div className="max-w-6xl mx-auto px-6">
        <div className="max-w-3xl">
          {/* Headline - Left Aligned */}
          <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-semibold text-foreground leading-[1.15] tracking-tight text-balance">
            Never Lose a Lead Again.{" "}
            <span className="text-accent">We Manage Your Inboxes</span>{" "}
            While You Grow Your Business.
          </h1>

          {/* Subheadline */}
          <p className="mt-6 text-base md:text-lg text-muted-foreground max-w-xl leading-relaxed">
            Professional, reliable social media comment and inquiry management for South African entrepreneurs.
          </p>

          {/* CTA Button */}
          <div className="mt-10">
            <Button 
              size="lg" 
              className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 h-12 text-sm font-medium"
            >
              Get Started
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
