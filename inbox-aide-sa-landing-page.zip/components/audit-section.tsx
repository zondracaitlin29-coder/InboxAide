import { Button } from "@/components/ui/button"
import { MessageCircle } from "lucide-react"

export function AuditSection() {
  return (
    <section id="audit" className="py-20 md:py-28 bg-background">
      <div className="max-w-6xl mx-auto px-6">
        {/* Audit Card with Gold Border */}
        <div className="border border-accent rounded-md p-8 md:p-12 bg-card shadow-sm">
          <div className="max-w-2xl">
            {/* Title */}
            <h2 className="font-serif text-2xl md:text-3xl font-semibold text-foreground tracking-tight mb-4">
              Unsure if your inbox needs help?
            </h2>
            
            {/* Description */}
            <p className="text-muted-foreground leading-relaxed mb-8">
              Let us review your current response time and comment engagement completely free of charge. 
              We&apos;ll show you exactly where you might be losing potential paying clients.
            </p>

            {/* CTA Button */}
            <Button 
              asChild
              size="lg" 
              className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 h-12 text-sm font-medium"
            >
              <a 
                href="https://wa.me/27768260594?text=Hi%20Inbox%20Aide%20SA,%20I'd%20love%20to%20request%20a%20free%20audit%20for%20my%20business%20social%20media%20pages!"
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle className="mr-2 w-4 h-4" />
                Claim Your Free Audit via WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
