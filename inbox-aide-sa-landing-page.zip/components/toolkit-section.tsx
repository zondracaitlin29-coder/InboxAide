import { CheckCircle } from "lucide-react"

const categories = [
  "Pricing & Quotes",
  "Bookings",
  "Complaints",
  "Payments",
  "Follow-ups"
]

export function ToolkitSection() {
  return (
    <section className="py-20 md:py-28 bg-[#1A1A1A]">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-12 md:mb-16">
          <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-[#F5F0E8] tracking-tight mb-4">
            Empower Your Internal Team
          </h2>
          <p className="text-[#F5F0E8]/60 max-w-2xl mx-auto text-balance">
            Prefer to manage your own inbox? Equip your business with our plug-and-play communication assets.
          </p>
        </div>

        {/* Product Card */}
        <div className="max-w-3xl mx-auto">
          <div className="bg-[#111111] rounded-lg border border-[#C9A227]/20 overflow-hidden">
            <div className="p-8 md:p-12">
              {/* Product Name */}
              <p className="text-[#C9A227] text-xs font-medium tracking-widest uppercase mb-4">
                The WhatsApp Response Toolkit
              </p>
              
              {/* Headline */}
              <h3 className="font-serif text-xl md:text-2xl font-medium text-[#F5F0E8] mb-6 leading-snug">
                90+ Ready-to-Send Professional Replies for South African Small Businesses
              </h3>

              {/* Price */}
              <div className="mb-8">
                <span className="text-3xl font-semibold text-[#C9A227]">R120</span>
                <span className="text-[#F5F0E8]/40 text-sm ml-2">once-off</span>
              </div>

              {/* Categories */}
              <div className="mb-8">
                <div className="flex flex-wrap gap-2">
                  {categories.map((category, index) => (
                    <span 
                      key={index}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-[#C9A227]/20 rounded text-xs text-[#F5F0E8]/70"
                    >
                      <CheckCircle className="w-3 h-3 text-[#C9A227]" />
                      {category}
                    </span>
                  ))}
                </div>
              </div>

              {/* CTA Button */}
              <a
                href="https://selar.co/237dq65411"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center bg-[#C9A227] hover:bg-[#A68B1F] text-[#111111] font-medium px-6 py-3 rounded transition-colors text-sm"
              >
                Buy & Download Instantly
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
