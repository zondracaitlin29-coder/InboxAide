import { KeyRound, Headphones, Rocket } from "lucide-react"

const steps = [
  {
    icon: KeyRound,
    number: "01",
    title: "Hand Over the Keys",
    subtitle: "Secure Onboarding"
  },
  {
    icon: Headphones,
    number: "02",
    title: "We Manage the Noise",
    subtitle: "Daily Professional Response Management"
  },
  {
    icon: Rocket,
    number: "03",
    title: "Watch Your Sales Grow",
    subtitle: "Never Miss a Hot Lead Again"
  }
]

export function ProcessSection() {
  return (
    <section id="process" className="py-20 md:py-28 bg-secondary">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">
            How It Works
          </h2>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Connector Line (desktop only) */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-5 left-[calc(50%+2rem)] w-[calc(100%-4rem)] h-px bg-border" />
              )}
              
              <div className="flex items-start gap-4">
                {/* Number Circle */}
                <div className="flex-shrink-0 w-10 h-10 rounded-full border-2 border-accent bg-card flex items-center justify-center">
                  <span className="text-sm font-semibold text-accent">{step.number}</span>
                </div>

                {/* Content */}
                <div>
                  <h3 className="font-medium text-foreground mb-1">
                    {step.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {step.subtitle}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
