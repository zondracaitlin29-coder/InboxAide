import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      {/* Final CTA Section */}
      <div className="max-w-6xl mx-auto px-6 py-16 md:py-20">
        <div className="max-w-xl">
          <h2 className="font-serif text-2xl md:text-3xl font-semibold text-foreground tracking-tight mb-4">
            Ready to Stop Missing Leads?
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-8">
            Join dozens of South African entrepreneurs who&apos;ve taken back their time and grown their businesses.
          </p>
          <Button 
            size="lg" 
            className="bg-primary text-primary-foreground hover:bg-primary/90 px-8 h-12 text-sm font-medium"
          >
            Get Started Today
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-border">
        <div className="max-w-6xl mx-auto px-6 py-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            {/* Brand & Copyright */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
              <span className="font-serif text-sm font-medium text-foreground">
                Inbox Aide <span className="text-accent">SA</span>
              </span>
              <span className="text-sm text-muted-foreground">
                &copy; {new Date().getFullYear()} All rights reserved.
              </span>
            </div>

            {/* Operating Hours */}
            <p className="text-sm text-muted-foreground">
              Operating Hours: Monday to Friday, 9:00 AM - 5:00 PM
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
