import { MessageSquareOff, MessagesSquare, Clock } from "lucide-react"

const problems = [
  {
    icon: MessageSquareOff,
    title: "Missed DMs & Lost Sales",
    description: "Every unanswered message is a potential customer walking away."
  },
  {
    icon: MessagesSquare,
    title: "Overwhelmed by Comments",
    description: "Genuine inquiries get buried under the noise of endless notifications."
  },
  {
    icon: Clock,
    title: "Zero Work-Life Balance",
    description: "You're glued to your phone instead of focusing on your business."
  }
]

export function ProblemSection() {
  return (
    <section id="problem" className="py-20 md:py-28 bg-card">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <h2 className="font-serif text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight">
            Is your inbox costing you clients?
          </h2>
        </div>

        {/* Problem Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {problems.map((problem, index) => (
            <div 
              key={index}
              className="bg-background border border-border rounded-md p-6 hover:border-accent/40 hover:shadow-sm transition-all duration-200"
            >
              {/* Icon */}
              <div className="w-10 h-10 rounded-md bg-secondary flex items-center justify-center mb-5">
                <problem.icon className="w-5 h-5 text-foreground" />
              </div>
              
              {/* Content */}
              <h3 className="font-medium text-foreground mb-2">
                {problem.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {problem.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
